from flask import Blueprint, make_response
from blueprints.user_data import get_user
from datetime import datetime, timezone
from email.utils import format_datetime

bp = Blueprint("v1", __name__, url_prefix="/users")

@bp.route("/<int:uid>")
def get(uid):
    u = get_user(uid)

    if not u:
        return {"error": "nf"}, 404 

    data = {
        "id": uid,
        "full_name": f"{u['first_name']} {u['last_name']}",
        "email": u["email"]
    }

    response = make_response(data)

    sunset_date = datetime (
        2026, 12, 31, 23, 59, 59,
        tzinfo = timezone.utc
    )

    response.headers["Sunset"] = format_datetime(
        sunset_date, usegmt=True
    )
    response.headers["Deprecation"] = "true"

    return response